package com.app.cadastroa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroAApplicationTests {

	@Test
	void contextLoads() {
	}

}
