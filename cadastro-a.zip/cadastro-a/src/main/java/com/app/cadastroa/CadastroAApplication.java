package com.app.cadastroa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroAApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroAApplication.class, args);
	}

}
